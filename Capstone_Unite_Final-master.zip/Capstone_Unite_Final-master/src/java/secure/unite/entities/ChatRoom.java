/**
 *
 * @author Patrick
 */

package secure.unite.entities;

public class ChatRoom {

    public String room;

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

}