/*
 *
 * Author:      Patrick Bartholomew
 * Date:        3/13/2016
 * Modified:    3/13/2016
 * Description: This bean is repsonsible for getting the list of available group
 *              chat rooms.
 *
 */
package chat.websocket;

public class Chatrooms {
    
    
    
}
