/*

    password hasher to be ran on every new account made before it's stored into the DB

 */
package secure.unite.entities;


public class passwordHash {
    
}
